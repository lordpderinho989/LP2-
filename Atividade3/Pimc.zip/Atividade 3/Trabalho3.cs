﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        Double peso, altura, resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(TxtPeso.Text, out peso)
                || (peso <= 0))
            {
                MessageBox.Show("raio inválido!");
                TxtPeso.Focus();
            }

            if (!Double.TryParse(TxtAltura.Text, out altura)
                || (altura <= 0))
            {
                MessageBox.Show("altura inválida!");
                TxtAltura.Focus();
            }
            else
            {
                resultado = peso / Math.Pow(altura, 2);
                TxtResultado.Text = resultado.ToString("N2");
            }
        }

        private void txtpeso_validated(object sender, EventArgs e)
        {
            
        }
    }

}
