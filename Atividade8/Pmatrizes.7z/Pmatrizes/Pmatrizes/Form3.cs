﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmatrizes
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void frmExercicio5_Load(object sender, EventArgs e)
        {

        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int[,] questoes = new int[7, 10];
            char[] gabarito = new char[10] { 'A', 'B', 'C', 'D', 'E', 'A', 'B', 'C', 'D', 'E' };
            char resposta;
            string auxiliar = "";
            int i, j;

            for (i = 0; i < 7; i++)
            {
                for (j = 0; j < 10; j++)
                {
                    auxiliar = Interaction.InputBox($"Aluno {i + 1} digite a resposta da pergunta {j + 1}: ", "Gabarito");

                    if (auxiliar.Length > 1 || !(gabarito.Contains(char.ToUpper(auxiliar[0]))))
                    {
                        MessageBox.Show("Digite uma resposta valída");
                        j--;
                    }
                    else
                    {
                        if (char.ToUpper(auxiliar[0]) == gabarito[j])
                        {
                            listgabarito.Items.Add($"O aluno:{i + 1} acertou a questão:{j + 1} era {gabarito[j]} escolheu {char.ToUpper(auxiliar[0])}");
                        }
                        else
                        {
                            listgabarito.Items.Add($"O aluno:{i + 1} errou a questão:{j + 1} era {gabarito[j]} escolheu {char.ToUpper(auxiliar[0])}");

                        }
                    }
                }

            }


        }
    }
}
