﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];

            string auxiliar = " ";

            for (int i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o número", "Entrada de dados");

                if (int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("valor invalido");

                    i--;

                }

                Array.Reverse(vetor);

                auxiliar = "";

                auxiliar = string.Join(" ", vetor);

                MessageBox.Show(auxiliar);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ArrayList Lista = new ArrayList() { "Ana", "André", "Beatriz", "Camilla", "Joao", "Joana", "Otávio", "Marcelo", "Pedro", "thais" }; ;

            Lista.Remove("Otávio");
            string auxiliar = " ";

            foreach (string nome in Lista)
            {

                auxiliar += nome + " ";

            }

            MessageBox.Show(auxiliar);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Double[,] notas = new Double[20, 3];
            Double media;
            string saida;
            string auxiliar = " ";

            for (int i = 0; i < 20; i++)
            {
                media = 0;

                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota {j + 1}", "Entrada de dados");


                    if (!Double.TryParse(auxiliar, out notas[i, j]) || notas[i, j] < 0 || notas[i, j] > 10)
                    {
                        MessageBox.Show("Dado Inválido");
                        j--;
                    }
                    else
                    {
                        media += notas[i, j];
                    }
                }

                saida = $"Aluno: {i + 1} - Média: {media / 3:F2}";
                MessageBox.Show(saida);
            }
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            if(Application.OpenForms.OfType<FrmExercicio4>().Count()>0)
            {
                MessageBox.Show("Form já existe");
                Application.OpenForms["FrmExercicio4"].BringToFront();
            }
            else
            {
                FrmExercicio4 frm4 = new FrmExercicio4();
                frm4.Show();
            }
        }

        private void Exercicio5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio5>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                Application.OpenForms["FrmExercicio5"].BringToFront();
            }
            else
            {
                frmExercicio5 frm5 = new frmExercicio5();
                frm5.Show();
            }
        }
    }
}





