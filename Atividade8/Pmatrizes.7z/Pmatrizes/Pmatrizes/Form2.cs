﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pmatrizes
{
    public partial class FrmExercicio4 : Form
    {
        public FrmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] nome = new string[10];
            string auxiliar = "";
            int soma = 0;

            for (int i = 0; i < nome.Length; i++)
            {

                nome[0] = Interaction.InputBox($"Digite o nome{i + 1}", "Entrada de Dados");

                foreach (char w in nome[i]) 
                {
                    if (char.IsLetter(w))
                    {
                        soma++;
                    }
                }

                if (soma<=0)
                {
                    MessageBox.Show("Dado invalido!!");
                    i--;
                }

                listboxnames.Items.Add($"o nome {nome[i]} tem {soma} Caracteres");    
                soma = 0;
            

            
                    
            }

                

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
