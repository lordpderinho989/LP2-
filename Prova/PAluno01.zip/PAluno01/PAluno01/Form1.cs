﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;


namespace PAluno01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            int[,] notalunos = new int[5,3];
            string auxiliar = "";
            int calculo = 0;


            for (int i = 1; i < 5; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota do aluno {i}: e a media dos mesmos {j}", "nota");
                    // if (int.TryParse(auxiliar, out notaluno[i,j]))
                    

                    lstbxNotaAlunos.Items.Add($"Aluno {i} nota: {auxiliar} Professor{i} nota {auxiliar} ");
                }

                

            }

        }
    }
}

